import React from 'react';
import {Route, Routes} from 'react-router-dom';
import Dashboard from './dashboard';
import Signup from './signup';
import Login from './login';
import Home from './home';
import Logout from './logout';
import Registration from './registration';
import Drop from './drop';
import Course from './course';
import Running from './running';
import Dept from './dept';
import Instructor from './instructor';

import './css/App.css';
import './css/table.css';
import './css/extra.css'

const App = () => {

  return (
    
      <div className="wrapper">
      <h1 >WELCOME TO OUR IITB ASC</h1>
        <Routes>
          <Route path="/" element={<Dashboard />}>
          </Route>
          <Route path="/signup" element={<Signup />}>
          </Route>
          <Route path="/login" element={<Login />}>
          </Route>
          <Route path="/home" element={<Home />}>
          </Route>
          <Route path="/logout" element={<Logout />}>
          </Route>
          <Route path="/home/registration" element={<Registration />}>
          </Route>
          <Route path="/droping" element={<Drop />}>
          </Route>
          <Route path="/course/:cid" element={<Course />}>
          </Route>
          <Route path="/course/running" element={<Running />}>
          </Route>
          <Route path="/course/running/:dept_name" element={<Dept />}>
          </Route>
          <Route path="/instructor/:iid" element={<Instructor />}>
          </Route>
        </Routes>
    </div>

  );
}

export default App;