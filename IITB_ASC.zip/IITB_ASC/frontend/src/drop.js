import React, { useState, useEffect } from 'react';
import {useNavigate} from 'react-router-dom';
import './css/table.css';

const Drop = () => {
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [rows, setRows] = useState([]);
  const navigate = useNavigate();
  
  useEffect(()=>{
    fetch('http://localhost:8080/drop_courses', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
    })
    .then((res) => res.json())
    .then((data) => {
      if (data.error) {
        console.log('drop_page got no response from backend');
        setLoading(true);
      }
      else {
        console.log('drop_page got response from backend');
        setUsers(data);
        setRows(data.map(item => (
            <tr key={item.course_id}>
              <td><a href = {"http://localhost:3000/course/"+item.course_id}>{item.course_id}</a></td>
              <td>{item.sec_id}</td>
              <td><button type="submit" onClick={(event) => handleSubmit(event, item.course_id, item.sec_id, item.semester, item.year)}>Drop</button></td>
            </tr>
          )));
        setLoading(false);
      }

    })
    .catch((error) => {
      console.error(error);
      setLoading(true);
    })
  },[])

  const handleSubmit = (event, cid, sec_id, semester, year) => {
    event.preventDefault();
    console.log(cid);

    fetch('http://localhost:8080/drop', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ cid, sec_id, semester, year }),
      credentials: 'include',
    })
    .then((res) => res.json())
    .then((data) => {
      if (data.error) {
        console.log('drop got no response from backend');
      }
      else {
        console.log('drop got response from backend');
        if(data.success){
          console.log(data.message);
          alert(data.message);
          navigate('/home');
        }
        else{
          alert(data.message);
          console.log(data.message);
        }
      }
    })
    .catch((error) => {
      console.error(error);
    });
  };

  return loading ? <p>loading...</p> : ( 
    <form>
    <h2>Drop</h2>
    <p>Welcome to the Drop courses page</p>
    <h3>{users[0].semester} - {users[0].year}</h3>
    <table>
      <thead>
        <tr>
        <th>Course ID</th>
        <th>Section ID</th>
        <th>Drop</th>
        </tr>
      </thead>
      <tbody id ="body">{rows}</tbody>
    </table>
    <button type="submit" onClick={()=>{navigate('/logout')}}>Logout</button>
    </form>
  );
};



export default Drop;