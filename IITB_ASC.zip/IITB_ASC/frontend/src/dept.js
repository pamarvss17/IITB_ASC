import React, { useState, useEffect } from 'react';
import {  useNavigate, useParams} from 'react-router-dom';

const Dept = () => {
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [rows, setRows] = useState([]);
  const navigate = useNavigate();
  const params = useParams();
  const dept_name = params.dept_name;
  
  useEffect(()=>{
    fetch('http://localhost:8080/dept', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ dept_name }),
      credentials: 'include',
    })
    .then((res) => res.json())
    .then((data) => {
      if (data.error) {
        console.log('dept_page got no response from backend');
        setLoading(true);
      }
      else {
        console.log('dept_page got response from backend');
        console.log(data);
        setUsers(data);
        setRows(data.map(item => (
          <tr key={item.cid}>
            <td><a href = {"http://localhost:3000/course/"+item.cid}>{item.cid}</a></td>
            <td>{item.tit}</td>
            <td>{item.cred}</td>
            <td>{item.sec_id}</td>
          </tr>
        )));
        setLoading(false);
      }

    })
    .catch((error) => {
      console.error(error);
      setLoading(true);
    })
  },[])



  return loading ? <p>loading...</p> : ( 
    <form>
      <h2>{users[0].dept_name}</h2>
      <p>Welcome to the Department page</p>

      <table>
      <thead>
        <tr>
        <th>Course ID</th>
        <th>Title</th>
        <th>Credits</th>
        <th>Section ID</th>
        </tr>
      </thead>
      <tbody>{rows}</tbody>
    </table>
    <button type="submit" onClick={()=>{navigate('/course/running')}}>Running Departments</button>
    <button type="submit" onClick={()=>{navigate('/logout')}}>Logout</button>
    </form>
  );
};



export default Dept;