import React, { useState } from 'react';
import {useNavigate} from 'react-router-dom';

const Signup = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    event.preventDefault();

    fetch('http://localhost:8080/signup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
      credentials: 'include',
    })
    .then((res) => res.json())
    .then((data) => {
      if (data.error) {
        console.log('signup_page got no response from backend');
        setErrorMessage(data.error);
      }
      else {
        console.log('signup_page got response from backend');
        if(data.success){
          console.log(data.message);
          alert("Signup Succesful \n clilck OK to go to login page");
          navigate('/login');
        }
        else{
          console.log(data.message);
          alert("User already exists ");
        }
      }
    })
    .catch((error) => {
      setErrorMessage("An error occurred. Please try again later.");
      console.error(error);
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Signup</h2>
      <div>
        <label htmlFor="username">Username:</label>
        <input
          type="text"
          id="username"
          value={username}
          onChange={(event) => setUsername(event.target.value)}
        required/>
      </div>
      <div>
        <label htmlFor="password">Password:</label>
        <input
          type="password"
          id="password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
        required/>
      </div>
      {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
      <button type="submit" class="btn btn-primary btn-rounded">Signup</button>
      <br/>
      <h3>Already have an account?</h3>
      <button type="submit" class="btn btn-primary btn-rounded" onClick={()=>{navigate('/login')}}>Login</button>
    </form>
  );
};

export default Signup;


