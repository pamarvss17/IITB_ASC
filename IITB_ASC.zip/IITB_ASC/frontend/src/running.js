import React, { useState, useEffect } from 'react';
import {useNavigate} from 'react-router-dom';

const Running = () => {
  const [users, setUsers] = useState([])
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true)
  const [rows, setRows] = useState([]);
  
  useEffect(()=>{
    fetch('http://localhost:8080/running', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
    })
    .then((res) => res.json())
    .then((data) => {
      if (data.error) {
        console.log('running got no response from backend');
        setLoading(true);
      }
      else {
        console.log('running got response from backend');
        console.log(data);
        setUsers(data);
        setRows(data.map(item => (
          <tr key={item.dept_name}>
            <td><a href = {"http://localhost:3000/course/running/"+item.dept_name}>{item.dept_name}</a></td>
          </tr>
        )));
        setLoading(false);
      }

    })
    .catch((error) => {
      console.error(error);
      setLoading(true);
    })
  },[])



  return loading ? <p>loading...</p> : ( 
    <form>
      <h2>Running Departments</h2>
      <p>Welcome to the Running Departments page</p>
      <br></br>
      <h3>{users[0].semester} - {users[0].year}</h3>
      <table>
      <thead>
        <tr>
        <th>Department</th>
        </tr>
      </thead>
      <tbody>{rows}</tbody>
    </table>
    <button type="submit" onClick={()=>{navigate('/logout')}}>Logout</button>
    </form>
  );
};



export default Running;