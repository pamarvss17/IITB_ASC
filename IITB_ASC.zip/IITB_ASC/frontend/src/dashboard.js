import React from 'react';
import {useNavigate} from 'react-router-dom';

const Dashboard = () => {
    const navigate = useNavigate();

    return ( 
        <form>
        <h2>Dashboard</h2>
        <button type="submit" class="btn btn-primary btn-rounded" onClick={()=>{navigate('/signup')}}>Signup</button>
        <br/>
        <br/>
        <button type="submit" class="btn btn-primary btn-rounded" onClick={()=>{navigate('/login')}}>Login</button>
        </form>
      );
};

export default Dashboard;