import React, { useState, useEffect } from 'react';
import {useNavigate} from 'react-router-dom';
import './css/table.css';

const HomePage = () => {
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [rows, setRows] = useState([]);
  const navigate = useNavigate();
  
  useEffect(()=>{
    fetch('http://localhost:8080/home', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
    })
    .then((res) => res.json())
    .then((data) => {
      if (data.error) {
        console.log('home_page got no response from backend');
        setLoading(true);
      }
      else {
        console.log('home_page got response from backend');
        console.log(data[0].sem.split(','));
        setUsers(data);
        setRows(data.map(item => (
          <div>
            <h2>{item.sem.split(',')[0]} - {item.sem.split(',')[1]}</h2>
            
            <table>
              <thead>
                <tr>
                  <th>Course ID</th>
                  <th>Section ID</th>
                  <th>Time Slot ID</th>
                  <th>Grade</th>
                  </tr>
              </thead>
              <tbody>
                {
                  item.details.map(detail => (
                    <tr key={item.sem}>
                      <td><a href = {"http://localhost:3000/course/"+detail.split(',')[4]}>{detail.split(',')[4]}</a></td>
                      <td>{detail.split(',')[5]}</td>
                      <td>{detail.split(',')[6]}</td>
                      <td>{detail.split(',')[7]}</td>
                      </tr>
                  ))
                }

              </tbody>
            </table>
          </div>
        )));
        setLoading(false);
      }

    })
    .catch((error) => {
      console.error(error);
      setLoading(true);
    })
  },[])

  return loading ? <p>loading...</p> : ( 
    <form>
    <h2>Home</h2>
    <p>Welcome to the home page</p>

    <h3 style={{color:'green', textAlign:'center'}}> User Details</h3>
    <div className='user-details'>
      <h3 style={{float: 'right'}}>Department : {users[0].details[0].split(',')[2]}</h3>
      <h3 >ID : {users[0].details[0].split(',')[0]}</h3>
      <h3  style={{float: 'right'}}>Total Credits : {users[0].details[0].split(',')[3]}</h3>
      <h3>Name : {users[0].details[0].split(',')[1]}</h3>
      
    </div><br/>

    <h3 style={{color:'green', textAlign:'center'}}> Courses Taken</h3>

    {rows}
    <button type="submit" onClick={()=>{navigate('/droping')}}>Drop Courses</button>
    <button type="submit" onClick={()=>{navigate('/home/registration')}}>Register</button>
    <button type="submit" onClick={()=>{navigate('/course/running')}}>Running Departments</button>
    <button type="submit" onClick={()=>{navigate('/logout')}}>Logout</button>
    <br/><br/>
    </form>
  );
};



export default HomePage;