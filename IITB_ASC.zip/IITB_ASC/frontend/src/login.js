import React, { useState } from 'react';
import {useNavigate} from 'react-router-dom';

const Login = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (event) => {
    event.preventDefault();

    fetch('http://localhost:8080/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password }),
      credentials: 'include',
    })
    .then((res) => res.json())
    .then((data) => {
      if (data.error) {
        console.log('login_page got no response from backend');
        setErrorMessage(data.error);
      }
      else {
        console.log('login_page got response from backend');
        if(data.success){
          console.log(data.message);
          alert(data.message + "\n clilck OK to go to home page");
          navigate('/home');
        }
        else{
          console.log(data.message);
          alert(data.message);
        }
      }
    })
    .catch((error) => {
      setErrorMessage("An error occurred. Please try again later.");
      console.error(error);
    });
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Login</h2>
      <div>
        <label htmlFor="username">Username:</label>
        <input
          type="text"
          id="username"
          value={username}
          onChange={(event) => setUsername(event.target.value)}
        required/>
      </div>
      <div>
        <label htmlFor="password">Password: </label>
        <input
          type="password"
          id="password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
        required/>
      </div>
      {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
      <button type="submit" class="btn btn-primary btn-rounded" >Login</button>
      <br/>
      <h3>Dont have an account?</h3>
      <button type="submit" class="btn btn-primary btn-rounded" onClick={()=>{navigate('/signup')}}>Signup</button>
    </form>
  );
};

export default Login;


