import React, { useState, useEffect } from 'react';
import { useNavigate} from 'react-router-dom';

const Registration = () => {
  const [users, setUsers] = useState([])
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const [rows, setRows] = useState([]);
  const navigate = useNavigate();

  useEffect(()=>{
    fetch('http://localhost:8080/registration', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      credentials: 'include',
    })
    .then((res) => res.json())
    .then((data) => {
      if (data.error) {
        console.log('registration_page got no response from backend');
        setLoading(true);
      }
      else {
        console.log('registration_page got response from backend');
        console.log(data);
        setUsers(data);
        setRows(data.map(item => (
          <tr key={item.course_id}>
            <td><a href = {"http://localhost:3000/course/"+item.course_id}>{item.course_id}</a></td>
            <td>{item.title}</td>
            <td>{item.dept_name}</td>
            <td>{item.credits}</td>

            <td>
              <select defaultValue={item.sec_id[0]}> {
                item.sec_id.map(it => (
                  <option>{it}</option>
                ))
              }
              </select>
            </td>
          
            <td><button type="submit" onClick={(event) => handleSubmit(event, item.course_id, item.credits, item.semester, item.year)}>Register</button></td>
          </tr>
        )));
        setLoading(false);
      }

    })
    .catch((error) => {
      console.error(error);
      setLoading(true);
    })
  },[])

  const handleSubmit = (event, cid, credits, semester, year) => {
    event.preventDefault();
    const chosen_sec = event.target.parentNode.previousSibling.lastChild.value;
    const sec_id = chosen_sec;
    console.log("register",sec_id)
    fetch('http://localhost:8080/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ cid, credits, sec_id, semester, year}),
      credentials: 'include',
    })
    .then((res) => res.json())
    .then((data) => {
      if (data.error) {
        console.log('registration got no response from backend');
      }
      else {
        console.log('registration got response from backend');
        if(data.success){
          console.log(data.message);
          alert(data.message);
          navigate('/home');
        }
        else{
          console.log(data.message);
          alert(data.message);
        }
      }
    })
    .catch((error) => {
      console.error(error);
    });
  };


  const searchTable=(event)=>{
    event.preventDefault();
    
    var input, tbody, tr, td, i, txtValue;
    input = search.toUpperCase();
    tbody = document.getElementById("body");
    tr = tbody.getElementsByTagName("tr");
  
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td");
      for (var j = 0; j < td.length; j++) {
        txtValue = td[j].textContent || td[j].innerText;
        if (txtValue.toUpperCase().indexOf(input) > -1) {
          tr[i].style.display = "";
          break;
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  }




  return loading ? <p>loading...</p> : ( 
    <form>
    <h2>Registration</h2>
    <p>Welcome to the Registration page</p>

    <div className='search'>
    <input type="text" onChange={(event) => setSearch(event.target.value)} required/>
    <button type="submit" onClick={(event) => searchTable(event)}>Search</button>
    </div>

    <br/>
    <h3>{users[0].semester} - {users[0].year}</h3>
    <table>
      <thead>
        <tr>
        <th>Course ID</th>
        <th>Title</th>
        <th>Department</th>
        <th>Credits</th>
        <th>Section ID</th>
        <th>Register</th>
        </tr>
      </thead>
      <tbody id ="body">{rows}</tbody>
    </table>
    <button type="submit" onClick={()=>{navigate('/logout')}}>Logout</button>
    </form>
    
  );
};



export default Registration;