import React from 'react';
import {useNavigate} from 'react-router-dom'

const Logout = ()=>{
    const navigate = useNavigate();


    const handleSubmit = (event) => {
        event.preventDefault();
    
        fetch('http://localhost:8080/logout', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
        })
        .then((res) => res.json())
        .then((data) => {
          if (data.error) {
            console.log('logout_page got no response from backend');
          }
          else {
            console.log('logout_page got response from backend');
            console.log(data.message);
            navigate('/login');
          }
        })
        .catch((error) => {
          console.error(error);
        });
    };

    return (
        <form>
            <div>
            <h2>Logout</h2>
            <p>Are You sure you want to logout</p>
        </div>
        <button type="submit" onClick={handleSubmit} >Logout</button>
        </form>
        
    )
}

export default Logout;