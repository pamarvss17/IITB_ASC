import React, { useState, useEffect } from 'react';
import {  useNavigate, useParams} from 'react-router-dom';

const Course = () => {
  const [loading, setLoading] = useState(true)
  const [rows, setRows] = useState([]);
  const navigate = useNavigate();
  const params = useParams();
  const cid = params.cid;
  
  useEffect(()=>{
    fetch('http://localhost:8080/course', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ cid }),
      credentials: 'include',
    })
    .then((res) => res.json())
    .then((data) => {
      if (data.error) {
        console.log('course_page got no response from backend');
        setLoading(true);
      }
      else {
        console.log('course_page got response from backend');
        console.log(data);
        setRows(data.map(item => (
          <tr key={item.cid}>
            <td><a href = {"http://localhost:3000/course/"+item.cid}>{item.cid}</a></td>
            <td>{item.tit}</td>
            <td>{item.cred}</td>
            <td>{item.dept}</td>
            <td><a href = {"http://localhost:3000/course/"+item.pre_id}>{item.pre_id}</a></td>
            <td>{item.pre_tit}</td>
            <td><a href = {"http://localhost:3000/instructor/"+item.instr_id}>{item.instr_id}</a></td>
            <td>{item.semester}</td>
            <td>{item.year}</td>
          </tr>
        )));
        setLoading(false);
      }

    })
    .catch((error) => {
      console.error(error);
      setLoading(true);
    })
  },[])



  return loading ? <p>loading...</p> : ( 
    <form>
      <h2>Course</h2>
      <p>Welcome to the course page</p>
      <table>
      <thead>
        <tr>
        <th>Course ID</th>
        <th>Title</th>
        <th>Credits</th>
        <th>Department</th>
        <th>Prerequisite ID</th>
        <th>Prerequisite Title</th>
        <th>Instructor ID</th>
        <th>Semester</th>
        <th>Year</th>
        </tr>
      </thead>
      <tbody>{rows}</tbody>
    </table>
    <button type="submit" onClick={()=>{navigate('/course/running')}}>Running Departments</button>
    <button type="submit" onClick={()=>{navigate('/logout')}}>Logout</button>
    </form>
  );
};



export default Course;