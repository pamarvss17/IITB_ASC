import React, { useState, useEffect } from 'react';
import {  useNavigate, useParams} from 'react-router-dom';

const Instructor = () => {
  const [users, setUsers] = useState([])
  const [loading, setLoading] = useState(true)
  const [rows, setRows] = useState([]);
  const navigate = useNavigate();
  const params = useParams();
  const iid = params.iid;
  
  useEffect(()=>{
    fetch('http://localhost:8080/instructor', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ iid }),
      credentials: 'include',
    })
    .then((res) => res.json())
    .then((data) => {
      if (data.error) {
        console.log('instructor_page got no response from backend');
        setLoading(true);
      }
      else {
        console.log('instructor_page got response from backend');
        console.log(data);
        setUsers(data);
        setRows(data.map(item => (
          <tr key={item.id}>
            <td><a href = {"http://localhost:3000/course/"+item.course_id}>{item.course_id}</a></td>
            <td>{item.sec_id}</td>
            <td>{item.semester}</td>
            <td>{item.year}</td>
          </tr>
        )));
        setLoading(false);
      }

    })
    .catch((error) => {
      console.error(error);
      setLoading(true);
    })
  },[])



  return loading ? <p>loading...</p> : ( 
    <form>
      <h2>Welcome to the instructor page</h2>
      <h3>Instructor ID: {users[0].id}</h3>
      <h3>Name: {users[0].name}</h3>
      <h3>Deapartment: {users[0].dept_name}</h3>
      <table>
      <thead>
        <tr>
          <th>Course ID</th>
          <th>Section ID</th>
          <th>Semester</th>
          <th>Year</th>
        </tr>
      </thead>
      <tbody>{rows}</tbody>
    </table>
    <button type="submit" onClick={()=>{navigate('/course/running')}}>Running Departments</button>
    <button type="submit" onClick={()=>{navigate('/logout')}}>Logout</button>
    </form>
  );
};



export default Instructor;