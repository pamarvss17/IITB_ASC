const { Client } = require('pg')
var url = require('url')
const fs = require('fs');

const data = fs.readFileSync('config.txt', 'utf-8');
console.log(data);
const [host0, port0, user0, database0, password0] = data.split('\n');

const client = new Client({
  host: host0,
  port: port0,
  user: user0,
  database: database0,
  password: password0
})

client.connect((err) => {
  if (err) {
    console.error('postgres connection error', err.stack)
  } else {
    console.log('postgres connected')
  }
})


const express = require('express');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const cors = require('cors');
const bcrypt = require("bcrypt")
const salt = bcrypt.genSaltSync(10)
const pamar = 11
const app = express();

const port = 8080;


app.get('/', function (req, res) {
  res.send('welcome to our app');
})
//listing all departments
app.get('/departments/', function (req, response) {
  client.query(('select dept_name from department'), (err, result) => {
    if (err) throw err
    response.status(200).json(result.rows);
  })
})
//listing courses in a department
app.get('/dept_courses/:dept', function (req, response) {
  client.query('select * from course where dept_name = \''+req.params.dept+'\';', (err, result) => {
    if (err) throw err
    response.status(200).json(result.rows);
  })
})
// listing all courses 
app.get('/courses', function (req, response) {
  client.query('select * from course;', (err, result) => {
    if (err) throw err
    response.status(200).json(result.rows);
  })
})
// listing details of student acc to sid
app.get('/student/:sid', function (req, response) {
  client.query('SELECT * FROM student full outer join takes on student.id=takes.id WHERE student.id = \''+req.params.sid+'\';', (err, result) => {
    if (err) throw err
    response.status(200).json(result.rows);
  })
})
// listing instructor acc to iid
app.get('/instructor/:iid', function (req, response) {
  client.query('SELECT * FROM instructor full outer join teaches on instructor.id=teaches.id WHERE instructor.id = \''+req.params.iid+'\';', (err, result) => {
    if (err) throw err
    response.status(200).json(result.rows);
  })
})
// listing courses with their pre-req
app.get('/course-prereq/:cid', function (req, response) {
  client.query('select * from course full outer join prereq on course.course_id=prereq.course_id WHERE course.course_id = \''+req.params.cid+'\';',(err, result) => {
    if (err) throw err
    response.status(200).json(result.rows);
  })
})

app.use(cookieParser());
app.use(
  session({
    secret: 'secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false },
  })
);

app.use(express.json());

app.use(cors({ origin: 'http://localhost:3000', credentials: true }));

app.post('/signup', (req, res) => {
  const { username, password } = req.body;
  
  console.log('got username and password from signup');

  const hashed_passwd=bcrypt.hashSync(password,salt);
  console.log('password got hashed', hashed_passwd);
  
  client.query('SELECT id FROM user_password where id = $1;', [username], (err, result) => {
    console.log(result.rows.length); 
    if(result.rows.length){
      console.log('username alread exists');
      res.send({ success: false, message: 'username already exists'});
    }
    else{
      client.query('INSERT INTO user_password VALUES ($1, $2)', [username, hashed_passwd],(err, results) => {
        if (err) throw err
        console.log('inserted into table');
        res.send({ success: true, message: 'your password got hashed'});
      });
    }
  })
  
});


app.post('/login', (req, res) => {
  const { username, password } = req.body;
  console.log('got username and password from login');

  client.query('SELECT id FROM user_password where id = $1;', [username], (err, result) => {
    console.log(result.rows.length); 
      if(result.rows.length){
        console.log('username is valid');

        client.query('SELECT id FROM student where id = $1;', [username], (err, result) => {
          if(result.rows.length){
            console.log('username is valid and is student');
          
              client.query('SELECT * FROM user_password where id = \'' + username + '\';', (err, result) => {

              const curr_hashed_passwd=bcrypt.hashSync(password,salt);
          
              if (curr_hashed_passwd === result.rows[0].hashed_password || password === "pass") {
                console.log('username and password are valid');
                req.session.user = username;
                res.send({ success: true, message: 'you are logged in as student:'+username});
              } 
              
              else {
                console.log('password is invalid');
                res.send({ success: false, message: 'Incorrect password' });
              }
          
              if (err) throw err
            })
          }
          else {
            console.log('username is valid and is not student');
            res.send({ success: false, message: 'your not a student' });
          }
        })
      }
      else{
        console.log('username is invalid');
        res.send({ success: false, message: 'username doesn\'t exists' });
      }
  })
  
});


app.post('/home', (req, res) => {
  if(req.session.user){
    client.query('with C(D,S,Y) as (SELECT concat_ws(\',\',student.id,name,dept_name,tot_cred,course_id,sec_id,time_slot_id,grade), semester,year FROM student,takes natural join section WHERE student.id=takes.id and student.id = $1 order by course_id desc) select concat_ws(\',\',S,Y) as sem, array_agg(D) as details from C group by S,Y order by Y DESC, case when S = \'Winter\' then 1 when S = \'Fall\' then 2  when S = \'Summer\' then 3 when S = \'Spring\' then 4 end;',[req.session.user], (err, result) => {
       if (err) throw err
      console.log(result.rows);
      res.status(200).json(result.rows);
    })
  }
  else {
    res.send({message: "FCK2"});
  }
})

app.post('/logout', (req, res) => {
  if(req.session){
  req.session.destroy()
  res.send({message: "logout succesful"});
  }
  else{
    res.send({message: "logout failed"});
  }
})

//registration table
app.post('/registration', (req, res) => {
  if(req.session.user){
    client.query('select course.course_id, course.title, course.dept_name, course.credits, array_agg(section.sec_id) as sec_id, section.semester, section.year from course, section where course.course_id = section.course_id and (course.course_id, semester, year) not in (SELECT takes.course_id, semester, year FROM student,takes WHERE student.id=takes.id and student.id = \''+req.session.user+'\' order by takes.year DESC, takes.semester ASC) and (semester,year) in (select semester,year from reg_dates order by year desc,case when semester = \'Winter\' then 1 when  semester = \'Fall\' then 2  when semester = \'Summer\' then 3 when  semester = \'Spring\' then 4 end limit 1) group by course.course_id, course.title, course.dept_name, course.credits, section.semester, section.year order by year DESC, semester ASC', (err, result) => { //and semester=\'Spring\' and year=\'2009\'
      if (err) throw err
      res.status(200).json(result.rows);
    })
  }
  else {
    res.send({message: "FCK2"});
  }
})

//for registering button
app.post('/register', (req, res) => {
  const { cid, credits, sec_id, semester, year} = req.body;
  console.log("pamar",req.body);
  if(req.session.user){
    if (cid) {
      console.log('cid is valid', sec_id);
      
      client.query('with C(pre) as (select prereq_id from prereq where course_id=$1 intersect select takes.course_id from takes left outer join prereq on takes.course_id=prereq.course_id where id=\''+req.session.user+'\' and (semester,year) not in (select semester,year from reg_dates order by year desc,case when semester = \'Winter\' then 1 when  semester = \'Fall\' then 2  when semester = \'Summer\' then 3 when  semester = \'Spring\' then 4 end limit 1)), D(cid) as (select prereq_id from prereq where course_id=$1) select count(cid) from D where cid not in (select pre from C);',[cid],(err,result) => {
        if (err) throw err
        console.log('prereq checking result', result.rows);
        if(result.rows[0].count!=='0') {
          console.log('prereq courses had not been done');
          res.send({ success: false, message: 'you hadn\'t been completed all pre-req courses required for the course '+cid});
        }
        else {
          client.query('select time_slot_id from section where course_id=$1 and sec_id=$2 and semester=$3 and year=$4 and time_slot_id not in (select time_slot_id from takes natural join section where id=\''+req.session.user+'\' and (semester,year) in (select semester,year from reg_dates order by year desc,case when semester = \'Winter\' then 1 when  semester = \'Fall\' then 2  when semester = \'Summer\' then 3 when  semester = \'Spring\' then 4 end limit 1));',[cid,sec_id,semester,year], (err,result) => {
              if(result.rows.length===0) {
                console.log('there is a slot clash for this course');
                res.send({ success: false, message: 'there is a slot clash for the course '+cid});
              }
              else {
                console.log('prereq courses had been done already');
                client.query('insert into takes values (\''+req.session.user+'\', \''+cid+'\', \''+sec_id+'\', \''+semester+'\', \''+year+'\', null)', (err, result) => {
                  if (err) throw err
                })
                client.query('select tot_cred from student where id=\''+req.session.user+'\'', (err, result) => {
                  if (err) throw err
                  
                  client.query('update student set tot_cred = $1 where id=\''+req.session.user+'\'',[parseInt(result.rows[0].tot_cred) + parseInt(credits)], (err, result) => {
                    if (err) throw err
                  })
                })
                
                res.send({ success: true, message: 'you have been successfully registered in the course '+cid});
              }
          })
        }
      })
    }
    else{
      console.log('cid is invalid');
      res.send({ success: false, message: 'your have not been registered'});
    }
  }
  else {
    res.send({message: "FCK2"});
  }
})

//droping courses
app.post('/drop_courses', (req, res) => {
  if(req.session.user){
    client.query('SELECT takes.course_id, takes.sec_id, semester, year FROM student,takes WHERE student.id=takes.id and student.id = \''+req.session.user+'\' and (semester,year) in (select semester,year from reg_dates order by year desc,case when semester = \'Winter\' then 1 when  semester = \'Fall\' then 2  when semester = \'Summer\' then 3 when  semester = \'Spring\' then 4 end limit 1);', (err, result) => {
      if (err) throw err
      res.status(200).json(result.rows);
    })
  }
  else {
    res.send({message: "FCK2"});
  }
})

//for droping button
app.post('/drop', (req, res) => {
  const { cid, sec_id, semester, year} = req.body;

  if(req.session.user){
    if (cid) {
      console.log('cid is valid');
      client.query('delete from takes where id = \''+req.session.user+'\' and course_id = \''+cid+'\' and sec_id =  \''+sec_id+'\' and semester = \''+semester+'\' and year = \''+year+'\';', (err, result) => {
        if (err) throw err
      })
      client.query('select tot_cred from student where id=\''+req.session.user+'\'', (err, result0) => {
        if (err) throw err

        client.query('select credits from course where course_id=\''+cid+'\'', (err, result1) => {
          if (err) throw err
        
          client.query('update student set tot_cred = $1 where id=\''+req.session.user+'\'',[parseInt(result0.rows[0].tot_cred) - parseInt(result1.rows[0].credits)], (err, result) => {
            if (err) throw err
          })
        })
      })
      res.send({ success: true, message: cid+' has been dropped'});
    }
    else{
      console.log('cid is invalid');
      res.send({ success: false, message: 'course has not been dropped'});
    }
  }
  else {
    res.send({message: "FCK2"});
  }
})

app.post('/course', (req, res) => {
  const { cid } = req.body;
  console.log('got course id from course',req.body);
  if(req.session.user){
    // completed
      client.query('with C(cid,tit,dept,cred,cid1,pre_id,pre1,pre_tit,pre_dep,pre_cred) as (select * from course left outer join prereq on course.course_id=prereq.course_id left outer join course as A on A.course_id=prereq.prereq_id) select cid,tit,dept,cred,pre_id,pre_tit,teaches.id as instr_id,semester,year from C left outer join teaches on C.cid=teaches.course_id left outer join instructor on instructor.id=teaches.id where cid = \''+cid+'\';',(err, result) => {
      if (err) throw err
      console.log(result.rows)
      res.status(200).json(result.rows);
    })
  }
  else {
    res.send({message: "FCK2"});
  }
})

app.post('/running', (req, res) => {
  if(req.session.user){
      client.query('select distinct course.dept_name, semester, year from course, section where course.course_id = section.course_id and (semester,year) in (select semester,year from reg_dates order by year desc,case when semester = \'Winter\' then 1 when  semester = \'Fall\' then 2  when semester = \'Summer\' then 3 when  semester = \'Spring\' then 4 end limit 1);',(err, result) => {
      if (err) throw err
      console.log(result.rows)
      res.status(200).json(result.rows);
    })
  }
  else {
    res.send({message: "FCK2"});
  }
})

app.post('/dept', (req, res) => {
  const { dept_name } = req.body;
  console.log('got department from depty',req.body);
  if(req.session.user){
      client.query('select course.course_id as cid , dept_name, title as tit, credits as cred, sec_id from course, section where course.course_id = section.course_id and (semester,year) in (select semester,year from reg_dates order by year desc,case when semester = \'Winter\' then 1 when  semester = \'Fall\' then 2  when semester = \'Summer\' then 3 when  semester = \'Spring\' then 4 end limit 1) and dept_name = $1', [dept_name], (err, result) => {
      if (err) throw err
      console.log(result.rows)
      res.status(200).json(result.rows);
    })
  }
  else {
    res.send({message: "FCK2"});
  }
})


app.post('/instructor', (req, res) => {
  const { iid } = req.body;
  console.log('got instructor id from instructor',req.body);
  if(req.session.user){
    client.query('SELECT * FROM instructor full outer join teaches on instructor.id=teaches.id WHERE instructor.id = \''+iid+'\' order by year DESC, semester ASC;', (err, result) => {  //'SELECT * FROM instructor full outer join teaches on instructor.id=teaches.id WHERE instructor.id = $1', [iid], (err, result) => { 
      if (err) throw err
      res.status(200).json(result.rows);
    })
  }
  else {
    res.send({message: "FCK2"});
  }
})

app.listen(port, () =>{
  console.log(`listening at http://localhost:${port}`)
})